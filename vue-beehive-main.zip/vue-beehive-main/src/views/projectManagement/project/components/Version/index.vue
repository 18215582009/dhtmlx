<template>
  <div class="version">版本</div>
</template>

<script>
  export default {
    name: 'Version',
  };
</script>

<style lang="scss" scoped>
  .version {
    width: 1076px;
    min-height: 100%;
    margin: 0 auto;
    background-color: #fff;
    text-align: center;
    line-height: 4.5em;
  }
</style>
