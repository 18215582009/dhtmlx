<template>
  <div class="events">日程</div>
</template>

<script>
  export default {
    name: 'Events',
  };
</script>

<style lang="scss" scoped>
  .events {
    width: 1076px;
    min-height: 100%;
    margin: 0 auto;
    background-color: #fff;
    text-align: center;
    line-height: 4.5em;
  }
</style>
