'use strict';

module.exports = {
  // queryUserResponse: {
  //   users: { type: 'array', itemType: 'user' },
  //   pageNo: { type: 'integer' },
  //   pageSize: { type: 'integer' },
  //   totalCount: { type: 'integer' },
  //   hasNextPage: { type: 'boolean' },
  // },
};
