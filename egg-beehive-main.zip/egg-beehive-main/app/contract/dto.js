'use strict';

module.exports = {
  // user: {
  //   id: { type: 'number', description: 'id 唯一键' },
  //   file: { type: 'file', description: '文件' },
  // },
};
