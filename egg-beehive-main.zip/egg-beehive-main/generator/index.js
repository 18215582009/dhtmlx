'use strict';
require('./lib/migrations');
require('./lib/model');
require('./lib/contract');
require('./lib/controller');
require('./lib/service');
require('./lib/router');
require('./lib/test');
